most geopackage files are in crs EPSG:32633 unless noted otherwise

units are in metres
